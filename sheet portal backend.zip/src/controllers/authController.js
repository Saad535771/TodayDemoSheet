import { validationResult } from "express-validator";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

export function makeAuthController({ User }) {
  const normalizeEmail = (email) => email?.trim().toLowerCase();

  const getTrashAccessByRole = (role, requestedAccess = 0) => {
    if (role === "admin") return 1;
    if (role === "hod") return 0;
    return requestedAccess ? 1 : 0;
  };

  return {
    // --- 1. LOGIN ---
    async login(req, res) {
      try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
          console.log("LOGIN VALIDATION ERRORS:", errors.array());
          return res.status(400).json({ errors: errors.array() });
        }

        const { email, password, role } = req.body;
        const normalizedEmail = normalizeEmail(email);

        console.log("LOGIN REQUEST:", {
          email: normalizedEmail,
          role
        });

        const user = await User.findOne({ where: { email: normalizedEmail } });

        console.log("USER FOUND:", !!user);

        if (!user) {
          return res.status(401).json({ message: "Invalid credentials" });
        }

        console.log("DB USER:", {
          id: user.id,
          email: user.email,
          role: user.role
        });

        const ok = await bcrypt.compare(password, user.passwordHash);

        console.log("PASSWORD MATCH:", ok);

        if (!ok) {
          return res.status(401).json({ message: "Invalid credentials" });
        }

        // ROLE RESTRICTION
        if (user.role !== role) {
          return res.status(403).json({
            message: `Aapka account as a ${user.role} register hai. Baraye meherbani ${user.role} login form use karein.`
          });
        }

        const token = jwt.sign(
          { id: user.id, email: user.email, role: user.role },
          process.env.JWT_SECRET,
          { expiresIn: "7d" }
        );

        return res.json({
          token,
          user: {
            id: user.id,
            email: user.email,
            role: user.role,
            access_monthly: user.accessMonthly,
            access_demo: user.accessDemo,
            access_trash: user.accessTrash
          }
        });
      } catch (err) {
        console.error("LOGIN ERROR:", err);
        return res.status(500).json({ message: "Server error during login" });
      }
    },

    // --- 2. REGISTER (New Staff/Admin/HOD) ---
    async register(req, res) {
      if (req.user.role !== "admin") {
        return res
          .status(403)
          .json({ message: "Access denied. Only Admins can create staff." });
      }

      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }

      const { email, password, role } = req.body;
      const normalizedEmail = normalizeEmail(email);

      try {
        const existing = await User.findOne({ where: { email: normalizedEmail } });
        if (existing) {
          return res.status(400).json({ message: "User already exists" });
        }

        const passwordHash = await bcrypt.hash(password, 10);

        const newUser = await User.create({
          email: normalizedEmail,
          passwordHash,
          role: role || "staff",
          accessMonthly: 1,
          accessDemo: 1,
          accessTrash: getTrashAccessByRole(role || "staff", 0)
        });

        return res.json({
          message: "User created successfully",
          userId: newUser.id
        });
      } catch (err) {
        console.error("REGISTER ERROR:", err);
        return res.status(500).json({ message: "Server error creating user" });
      }
    },

    // --- 3. ME (Get Profile & Permissions) ---
    async me(req, res) {
      try {
        const user = await User.findByPk(req.user.id);

        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }

        return res.json({
          user: {
            id: user.id,
            email: user.email,
            role: user.role,
            access_monthly: user.accessMonthly,
            access_demo: user.accessDemo,
            access_trash: user.accessTrash
          }
        });
      } catch (err) {
        console.error("ME ERROR:", err);
        return res.status(500).json({ message: "Error fetching profile" });
      }
    },

    // --- 4. LIST ALL USERS (Admin Only) ---
    async listUsers(req, res) {
      if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }

      try {
        const users = await User.findAll({
          order: [["createdAt", "DESC"]]
        });

        const formattedUsers = users.map((u) => ({
          id: u.id,
          email: u.email,
          role: u.role,
          access_monthly: u.accessMonthly,
          access_demo: u.accessDemo,
          access_trash: u.accessTrash,
          createdAt: u.createdAt
        }));

        return res.json({ users: formattedUsers });
      } catch (e) {
        console.error("LIST USERS ERROR:", e);
        return res.status(500).json({ message: "Error fetching users" });
      }
    },

    // --- 5. UPDATE PERMISSIONS (Show/Hide Sheets) ---
    async updatePermissions(req, res) {
      if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }

      const { userId } = req.params;
      const { access_monthly, access_demo, access_trash } = req.body;

      try {
        const user = await User.findByPk(userId);

        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }

        const trashAccess = getTrashAccessByRole(user.role, access_trash);

        await User.update(
          {
            accessMonthly: access_monthly ? 1 : 0,
            accessDemo: access_demo ? 1 : 0,
            accessTrash: trashAccess
          },
          { where: { id: userId } }
        );

        return res.json({
          success: true,
          message: "Permissions updated"
        });
      } catch (e) {
        console.error("UPDATE PERMISSIONS ERROR:", e);
        return res.status(500).json({ message: "Error updating permissions" });
      }
    },

    // --- 6. DELETE USER ---
    async deleteUser(req, res) {
      if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Access denied" });
      }

      const { userId } = req.params;

      if (parseInt(userId, 10) === req.user.id) {
        return res.status(400).json({ message: "Cannot delete yourself" });
      }

      try {
        const deleted = await User.destroy({ where: { id: userId } });

        if (!deleted) {
          return res.status(404).json({ message: "User not found" });
        }

        return res.json({
          success: true,
          message: "User deleted"
        });
      } catch (e) {
        console.error("DELETE USER ERROR:", e);
        return res.status(500).json({ message: "Error deleting user" });
      }
    }
  };
}