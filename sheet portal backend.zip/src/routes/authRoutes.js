import { Router } from "express";
import { body, param } from "express-validator";
import { requireAuth } from "../middleware/auth.js";

export function makeAuthRoutes(authController) {
  const router = Router();

  // --- LOGIN ---
  router.post(
    "/login",
    [
      body("email")
        .trim()
        .toLowerCase()
        .isEmail()
        .withMessage("Valid email required"),

      body("password")
        .isString()
        .isLength({ min: 3 })
        .withMessage("Password required"),

      body("role")
        .trim()
        .isIn(["admin", "staff", "hod"])
        .withMessage("Invalid role selected")
    ],
    authController.login
  );

  // --- REGISTER ---
  router.post(
    "/register",
    requireAuth,
    [
      body("email")
        .trim()
        .toLowerCase()
        .isEmail()
        .withMessage("Valid email required"),

      body("password")
        .isString()
        .isLength({ min: 6 })
        .withMessage("Password min 6 chars"),

      body("role")
        .trim()
        .isIn(["admin", "staff", "hod"])
        .withMessage("Invalid role")
    ],
    authController.register
  );

  // --- CURRENT USER PROFILE ---
  router.get("/me", requireAuth, authController.me);

  // --- LIST USERS ---
  router.get("/users", requireAuth, authController.listUsers);

  // --- UPDATE USER PERMISSIONS ---
  router.put(
    "/users/:userId/permissions",
    requireAuth,
    [
      param("userId")
        .isInt({ min: 1 })
        .withMessage("Valid userId is required"),

      body("access_monthly")
        .optional()
        .isBoolean()
        .withMessage("access_monthly must be boolean"),

      body("access_demo")
        .optional()
        .isBoolean()
        .withMessage("access_demo must be boolean"),

      body("access_trash")
        .optional()
        .isBoolean()
        .withMessage("access_trash must be boolean")
    ],
    authController.updatePermissions
  );

  // --- DELETE USER ---
  router.delete(
    "/users/:userId",
    requireAuth,
    [
      param("userId")
        .isInt({ min: 1 })
        .withMessage("Valid userId is required")
    ],
    authController.deleteUser
  );

  return router;
}